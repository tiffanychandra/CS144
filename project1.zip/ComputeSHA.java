import java.io.*;
import java.security.*;
/**
  * Read input file content and calculate SHA-1 hash 
  * @param filename
  * @return the 40 digit hex value from the sequence of bytes 
  * @throws any exception caught during block of execution, such as faulty file 
*/
public class ComputeSHA {
	public static void main(String[] args) throws FileNotFoundException, IOException, NoSuchAlgorithmException {
		String input = args[0];
		File inputFile = new File(input);
		FileInputStream f = null;
		try {
			f = new FileInputStream(inputFile);
			MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
			byte[] buffer = new byte[8192];
			int c = 0;
			while (c != -1) {
				c = f.read(buffer);
				if (c > 0) {
					messageDigest.update(buffer, 0, c);
				}
			}
			byte[] bytes = messageDigest.digest();
			StringBuffer stringBuffer = new StringBuffer();
			for (int i = 0; i < bytes.length; i++) {
				stringBuffer.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
			}
			System.out.println(stringBuffer.toString());	
		}
		finally {
			if (f != null) {
				f.close();
			}
		}
	}
}

