-- create table called "Actors" in db "CS144"
create table Actors(name varchar(40), movie varchar(80), year int, role varchar(40));
-- load downloaded csv file into "Actors" table
load data local infile './actors.csv' into table Actors 
fields terminated by ',' optionally enclosed by '"';
-- query that returns the names of all actors in the movie 'Die Another Day'
select name from Actors where movie = 'Die Another Day';
-- drop "Actors" table
drop table Actors;
